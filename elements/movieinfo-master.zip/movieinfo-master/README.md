# MovieInfo App

JavaScript/jQuery app that fetches movie data from the OMDb API

## Usage

```bash
Run index.html on any server
```