/*
Bug: For Icon #3, background needs to be set to the color behind it to be matched.
*/

// ∑ //