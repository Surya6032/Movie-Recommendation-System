# Movie App
Built with Vanilla JavaScript. Below is a list of the methods and properties use

* querySelector
* createElement
* innerHTML
* appendChild
* insertBefore
* preventDefault
* dataset
* parentElement
* nextElementSibling
* classList
    * add
    * remove
* fetch
* bind
* setAttribute
* onClick
* toLowerCase
* target


### Video coming soon!!!