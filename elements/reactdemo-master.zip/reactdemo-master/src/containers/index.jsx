import MovieContainer from './MovieContainer';
import MovieDetail from './MovieDetail';
import StarDetail from './StarDetail';
import SearchBar from './SearchBar';

export {MovieContainer, MovieDetail, StarDetail, SearchBar};
