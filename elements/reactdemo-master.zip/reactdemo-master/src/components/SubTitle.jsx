import React  from 'react';

export default function SubTitle(props){
  return(
    <h4>{props.title}</h4>
  );
}
